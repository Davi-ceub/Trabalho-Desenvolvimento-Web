# Trabalho-Desenvolvimento-Web

Projeto: AgroSeed

Integrantes: Carlos Nascimento; Davi Castilho; Luís Vasconcelos; Marcos Soares.

  Os produtores de soja do Brasil precisão todo ano selecionar cultivares de soja para realizar o plantio das suas áreas. Com isso, cada produtor seleciona as cultivares das seguintes maneiras: da sua própria experiência, em relação as cultivares que mais produziram nas safras anteriores; em conversa com outros produtores; participação de dias de campo e outros eventos; contato direto com os vendedores das empresas que produzem e/ou vendem as cultivares de soja.

  Atualmente, existem cerca de 30 a 40 empresas e instituições que atuam como obtentoras (desenvolvedoras) de cultivares de soja no Brasil. No mercado ativo para a safra atual, estima-se que o produtor tenha à disposição entre 500 e 600 cultivares comerciais de soja. A complexidade dessa escolha é acentuada pela necessidade de cruzar variáveis agronômicas específicas (ciclo, biotecnologia, resistências e exigência de fertilidade) com as condições locais (região, regime hídrico e nível tecnológico). Nota-se, portanto, uma lacuna tecnológica: a ausência de uma ferramenta centralizada que conecte, de forma técnica e direta, a oferta das detentoras de genética à demanda específica de cada produtor. O valor total do mercado de sementes das cultivares de soja no Brasil está estimado em aproximadamente R$ 26,5 bilhões por safra.

  O projeto consiste no desenvolvimento de um sistema mobile desenhado para atuar como um hub de inteligência agronômica entre empresas do setor e produtores rurais:

  •	Para as Empresas: O sistema permite o cadastramento detalhado de portfólios, incluindo características de resistência a doenças e nematoides, ciclos de maturação e exigências de fertilidade. Além disso, fornece relatórios de leads qualificados, permitindo que as empresas identifiquem produtores interessados em seus materiais para prospecção comercial.
  
  •	Para os Produtores: O aplicativo oferece um sistema de filtragem avançada baseado em necessidades reais. Ao inserir o perfil de sua área (ex: região, nível tecnológico, histórico de doenças), o usuário recebe uma lista personalizada de cultivares aptas.
  
  Após o cadastro do produtor no aplicativo, ele poderá selecionar características agronômicas (já cadastradas no sistema) que melhor atende as suas necessidades, como por exemplo: soja convencional ou transgênica; ciclo (precoce/médio/tardio); comportamento (tolerância e/ou resistência) em relação a doenças fúngicas; comportamento (tolerância e/ou resistência) em relação a nematoides; exigência de fertilidade (baixa/média/alta); E outras características: região de cultivo (cerrado ou sul do país); cultivo em área de sequeiro ou irrigada; e o nível tecnológico (médio ou alto).
  
  Após a seleção das cultivares, pelos produtores rurais, as empresas terão acesso a um relatório, via aplicativo, indicando as informações sobre o produtor rural que selecionou a suas cultivares, para posterior contato e finalização da venda. O aplicativo também vai permitir que cada produtor rural tenha acessa ao seu histórico de seleção de cultivares a cada safra. Além disso, o aplicativo vai permitir e solicitar (via mensagens) que cada produtor rural faça a inserção da produtividade de cada cultivar após a colheita. Consideramos que essa informação será a de maior relevância para os produtores rurais que irão utilizar o aplicativo, pois esse é o parâmetro de maior relevância na escolha de uma cultivar de soja.
  
  Resultado esperado com o desenvolvimento do projeto: desenvolver uma solução multiplataforma que otimize o processo de tomada de decisão no campo, aumente a visibilidade comercial das empresas obtentoras e promova a melhoria da produtividade da soja brasileira por meio do uso estratégico de dados e características agronômicas/cultivo.

ENTREGA 2 
Baixar os arquivos das pastas agroseed e core e o arquivo manage.py
ativar o interpretador venv
iniciar o servidor 
utilizar as páginas html

# AgroSeed API

## Funcionalidades
- CRUD de Clientes
- CRUD de Produtos
- Registro de Vendas
- Controle de Estoque

## Tecnologias
- Django
- Django REST Framework
- SQLite

## Como rodar
```bash
python manage.py migrate
python manage.py runserver
